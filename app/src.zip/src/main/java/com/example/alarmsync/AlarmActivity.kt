package com.example.alarmsync

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.ui.*
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable

class AlarmActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val text = intent.getStringExtra("text") ?: "Alarm"

        setContent {
            Column {
                Text(text)
                Button(onClick = { finish() }) { Text("Dismiss") }
                Button(onClick = { finish() }) { Text("Snooze") }
            }
        }
    }
}